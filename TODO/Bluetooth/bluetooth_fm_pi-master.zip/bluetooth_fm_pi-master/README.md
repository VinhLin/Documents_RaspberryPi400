# bluetooth_fm_pi

* Incomplete
* Work in progress
Setup Script and resources for bluetooth audio fm radio transmitter
